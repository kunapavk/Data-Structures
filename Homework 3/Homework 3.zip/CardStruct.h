#include <string>

#ifndef CARD_STRUCT_H
#define CARD_STRUCT_H
struct card {
	int val;
	int suite;
};
#endif